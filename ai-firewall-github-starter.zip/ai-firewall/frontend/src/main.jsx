import React, {useEffect, useState} from "react";
import {createRoot} from "react-dom/client";
import "./styles.css";

const API = "http://localhost:8000";

function App() {
  const [adminKey, setAdminKey] = useState("admin-change-me");
  const [metrics, setMetrics] = useState({total:0, allowed:0, blocked:0});
  const [events, setEvents] = useState([]);
  const [policies, setPolicies] = useState([]);
  const [input, setInput] = useState("");
  const [result, setResult] = useState(null);

  async function load() {
    const headers = {"X-Admin-Key": adminKey};
    const [m, e, p] = await Promise.all([
      fetch(`${API}/v1/metrics`, {headers}),
      fetch(`${API}/v1/events`, {headers}),
      fetch(`${API}/v1/policies`, {headers})
    ]);
    if (m.ok) setMetrics(await m.json());
    if (e.ok) setEvents(await e.json());
    if (p.ok) setPolicies(await p.json());
  }

  async function testGuard() {
    const r = await fetch(`${API}/v1/guard`, {
      method: "POST",
      headers: {"Content-Type":"application/json", "X-API-Key":"change-me"},
      body: JSON.stringify({provider:"demo", model:"demo-model", input})
    });
    setResult(await r.json());
    await load();
  }

  useEffect(() => { load(); }, []);

  return <main>
    <header>
      <div>
        <h1>AI Firewall</h1>
        <p>Policy gateway for AI traffic</p>
      </div>
      <button onClick={load}>Refresh</button>
    </header>

    <section className="cards">
      <article><b>{metrics.total}</b><span>Total requests</span></article>
      <article><b>{metrics.allowed}</b><span>Allowed</span></article>
      <article><b>{metrics.blocked}</b><span>Blocked</span></article>
    </section>

    <section className="panel">
      <h2>Admin access</h2>
      <input value={adminKey} onChange={e=>setAdminKey(e.target.value)} />
    </section>

    <section className="panel">
      <h2>Test the firewall</h2>
      <textarea value={input} onChange={e=>setInput(e.target.value)}
        placeholder="Enter an AI prompt to evaluate..." />
      <button onClick={testGuard}>Evaluate</button>
      {result && <pre className={result.allowed ? "ok" : "blocked"}>{JSON.stringify(result, null, 2)}</pre>}
    </section>

    <section className="panel">
      <h2>Policies</h2>
      <table><thead><tr><th>Name</th><th>Action</th><th>Enabled</th></tr></thead>
      <tbody>{policies.map(p=><tr key={p.id}><td>{p.name}</td><td>{p.action}</td><td>{String(p.enabled)}</td></tr>)}</tbody>
      </table>
    </section>

    <section className="panel">
      <h2>Recent events</h2>
      <table><thead><tr><th>Time</th><th>Provider</th><th>Model</th><th>Action</th><th>Reason</th></tr></thead>
      <tbody>{events.map(e=><tr key={e.id}><td>{new Date(e.created_at).toLocaleString()}</td><td>{e.provider}</td><td>{e.model}</td><td>{e.action}</td><td>{e.reason}</td></tr>)}</tbody>
      </table>
    </section>
  </main>
}

createRoot(document.getElementById("root")).render(<App />);
