from __future__ import annotations

import hashlib
import re
import time
from collections import defaultdict, deque
from datetime import datetime, timezone
from typing import Any

from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict
from sqlalchemy import Boolean, DateTime, Integer, String, Text, create_engine, select
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, sessionmaker


class Settings(BaseSettings):
    app_api_key: str = "change-me"
    admin_api_key: str = "admin-change-me"
    database_url: str = "sqlite:///./data/firewall.db"
    cors_origins: str = "http://localhost:5173"
    max_input_chars: int = 12000
    rate_limit_per_minute: int = 30

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()

engine = create_engine(
    settings.database_url,
    connect_args={"check_same_thread": False} if settings.database_url.startswith("sqlite") else {},
)
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)


class Base(DeclarativeBase):
    pass


class Policy(Base):
    __tablename__ = "policies"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(120), unique=True)
    pattern: Mapped[str] = mapped_column(String(500))
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    action: Mapped[str] = mapped_column(String(20), default="block")


class AuditEvent(Base):
    __tablename__ = "audit_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    request_hash: Mapped[str] = mapped_column(String(64))
    provider: Mapped[str] = mapped_column(String(80))
    model: Mapped[str] = mapped_column(String(120))
    action: Mapped[str] = mapped_column(String(20))
    reason: Mapped[str] = mapped_column(Text)


Base.metadata.create_all(engine)

DEFAULT_POLICIES = [
    ("ignore-previous", r"ignore\s+(all\s+)?previous\s+instructions", True, "block"),
    ("system-prompt", r"(reveal|show|print|leak).{0,50}(system\s+prompt|hidden\s+instructions)", True, "block"),
    ("jailbreak", r"\b(jailbreak|dan\s+mode|developer\s+mode)\b", True, "block"),
    ("credential-exfil", r"(api[_ -]?key|password|secret|token).{0,40}(reveal|dump|exfiltrate|leak)", True, "block"),
]

with SessionLocal() as db:
    if not db.scalar(select(Policy.id).limit(1)):
        for name, pattern, enabled, action in DEFAULT_POLICIES:
            db.add(Policy(name=name, pattern=pattern, enabled=enabled, action=action))
        db.commit()


app = FastAPI(title="AI Firewall Gateway", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[x.strip() for x in settings.cors_origins.split(",") if x.strip()],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

rate_windows: dict[str, deque[float]] = defaultdict(deque)


class GuardRequest(BaseModel):
    provider: str = Field(min_length=1, max_length=80)
    model: str = Field(min_length=1, max_length=120)
    input: str = Field(min_length=1)


class GuardResponse(BaseModel):
    allowed: bool
    action: str
    reason: str
    request_hash: str


class PolicyIn(BaseModel):
    name: str
    pattern: str
    enabled: bool = True
    action: str = "block"


def db_session():
    with SessionLocal() as db:
        yield db


def require_api_key(x_api_key: str | None = Header(default=None)) -> None:
    if not x_api_key or not hashlib.sha256(x_api_key.encode()).digest() == hashlib.sha256(settings.app_api_key.encode()).digest():
        raise HTTPException(status_code=401, detail="Invalid API key")


def require_admin(x_admin_key: str | None = Header(default=None)) -> None:
    if not x_admin_key or x_admin_key != settings.admin_api_key:
        raise HTTPException(status_code=403, detail="Admin key required")


def enforce_rate_limit(client_ip: str) -> None:
    now = time.time()
    window = rate_windows[client_ip]
    while window and now - window[0] > 60:
        window.popleft()
    if len(window) >= settings.rate_limit_per_minute:
        raise HTTPException(status_code=429, detail="Rate limit exceeded")
    window.append(now)


def evaluate(text: str, policies: list[Policy]) -> tuple[str, str]:
    for policy in policies:
        if not policy.enabled:
            continue
        try:
            if re.search(policy.pattern, text, flags=re.IGNORECASE | re.DOTALL):
                return policy.action, f"Policy matched: {policy.name}"
        except re.error:
            continue
    return "allow", "No blocking policy matched"


def write_audit(db: Session, body: GuardRequest, action: str, reason: str) -> str:
    request_hash = hashlib.sha256(body.input.encode("utf-8")).hexdigest()
    db.add(AuditEvent(
        created_at=datetime.now(timezone.utc),
        request_hash=request_hash,
        provider=body.provider,
        model=body.model,
        action=action,
        reason=reason,
    ))
    db.commit()
    return request_hash


@app.get("/health")
def health():
    return {"status": "ok", "service": "ai-firewall-gateway"}


@app.post("/v1/guard", response_model=GuardResponse, dependencies=[Depends(require_api_key)])
def guard(
    body: GuardRequest,
    request: Request,
    db: Session = Depends(db_session),
):
    enforce_rate_limit(request.client.host if request.client else "unknown")

    if len(body.input) > settings.max_input_chars:
        request_hash = write_audit(db, body, "block", "Input exceeds maximum size")
        return GuardResponse(allowed=False, action="block", reason="Input too large", request_hash=request_hash)

    policies = list(db.scalars(select(Policy).order_by(Policy.id)))
    action, reason = evaluate(body.input, policies)
    request_hash = write_audit(db, body, action, reason)

    return GuardResponse(
        allowed=action == "allow",
        action=action,
        reason=reason,
        request_hash=request_hash,
    )


@app.get("/v1/metrics", dependencies=[Depends(require_admin)])
def metrics(db: Session = Depends(db_session)):
    events = list(db.scalars(select(AuditEvent)))
    return {
        "total": len(events),
        "allowed": sum(e.action == "allow" for e in events),
        "blocked": sum(e.action == "block" for e in events),
    }


@app.get("/v1/events", dependencies=[Depends(require_admin)])
def events(db: Session = Depends(db_session)):
    rows = list(db.scalars(select(AuditEvent).order_by(AuditEvent.id.desc()).limit(50)))
    return [
        {
            "id": e.id,
            "created_at": e.created_at.isoformat(),
            "provider": e.provider,
            "model": e.model,
            "action": e.action,
            "reason": e.reason,
            "request_hash": e.request_hash,
        }
        for e in rows
    ]


@app.get("/v1/policies", dependencies=[Depends(require_admin)])
def policies(db: Session = Depends(db_session)):
    return [
        {"id": p.id, "name": p.name, "pattern": p.pattern, "enabled": p.enabled, "action": p.action}
        for p in db.scalars(select(Policy).order_by(Policy.id))
    ]


@app.post("/v1/policies", dependencies=[Depends(require_admin)])
def add_policy(policy: PolicyIn, db: Session = Depends(db_session)):
    if policy.action not in {"allow", "block"}:
        raise HTTPException(status_code=400, detail="action must be allow or block")
    try:
        re.compile(policy.pattern)
    except re.error as exc:
        raise HTTPException(status_code=400, detail=f"Invalid regex: {exc}") from exc
    item = Policy(**policy.model_dump())
    db.add(item)
    db.commit()
    db.refresh(item)
    return {"id": item.id, **policy.model_dump()}


@app.patch("/v1/policies/{policy_id}", dependencies=[Depends(require_admin)])
def update_policy(policy_id: int, enabled: bool, db: Session = Depends(db_session)):
    item = db.get(Policy, policy_id)
    if not item:
        raise HTTPException(status_code=404, detail="Policy not found")
    item.enabled = enabled
    db.commit()
    return {"ok": True, "enabled": item.enabled}
